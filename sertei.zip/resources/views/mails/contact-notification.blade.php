<h1>Notificación desde Sitio Web</h1>

<h3>Nombre:</h3>
<p>
    {{ $name }}
</p>

<h3>Correo electrónico:</h3>
<p>
    {{ $email }}
</p>

<h3>Mensaje adicional:</h3>
<p>
    {{ $msg }}
</p>
