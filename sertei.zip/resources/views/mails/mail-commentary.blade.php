<h1>Notificación desde Sitio web Comentario</h1>

<h3>Comentario:</h3>
<p>
    {{ $commentary}}
</p>