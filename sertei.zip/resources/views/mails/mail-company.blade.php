<h1>Notificación desde Sitio Web Company</h1>

<h3>Nombre:</h3>
<p>
    {{ $name }}
</p>

<h3>Correo electrónico:</h3>
<p>
    {{ $email }}
</p>

<h3>Telefono:</h3>
<p>
    {{ $phone }}
</p>

<h3>Empresa:</h3>
<p>
    {{ $company }}
</p>
