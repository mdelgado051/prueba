
<?php $__env->startSection('title', 'Blog'); ?>
<?php $__env->startSection('meta-description', 'Blog'); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/blog.css')); ?>">
    <!-- Swiper -->
    <link rel="stylesheet" href="<?php echo e(asset('lib/swiper/swiper-bundle.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <section id="cover" class="container-fluid" style="background-image: url(<?php echo e(asset('img/blog/cover.jpg')); ?>)">
        <article class="container">
            <h1 class="text-uppercase text-white text-md-left text-center">
                Blog y Eventos
            </h1>
        </article>
    </section>
    <section id="eventos">
        <?php if(count($events)): ?>
            <h2 class="mb-4">Eventos recientes</h2>
        <?php endif; ?>
        <?php if(empty($events) || !count($events)): ?>
            <h2>No hay eventos recientes</h2>
        <?php endif; ?>
        <div class="swiper-events swiper-container">
            <div class="swiper-wrapper pb-4">
                
                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="swiper-slide">
                        <div class="event-img rounded text-white p-3"
                             style="background-image: url(<?php echo e($event->getFirstMediaUrl('event-gallery')); ?>)">
                            <p class="blog-date thin-text"><?php echo e($event->date->format('d-m-Y')); ?></p>
                            <h3 class="h4"><?php echo e($event->name); ?></h3>
                        </div>
                        <div class="event-cont p-3 small-text">
                            <p class="small-text">
                                <?php echo e($event->intro); ?>

                            </p>
                            <a class="btn btn-pill btn-primary py-1 small-text" href="<?php echo e(route('events.post', $event->slug)); ?>">Ver más</a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <section id="blog">
        <?php if(isset($events) && count($events)): ?>
            <h2 class="mb-md-4 mb-5 text-md-left text-center">Blog</h2>
        <?php endif; ?>

        <?php if(empty($posts) || !count($posts)): ?>
                <h2 class="mb-md-4 mb-5 text-md-left text-center">No hay artículos recientes</h2>
        <?php endif; ?>

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article
                    class="row flex-column-reverse align-items-center m-0 <?php echo e($key % 2 == 0 ? 'flex-md-row' : 'flex-md-row-reverse'); ?>">
                <div class="entry-summary col-md-6 my-md-0 my-4">
                    <h3 class="text-md-left text-center mx-md-0 mx-auto mb-3"><?php echo e($post->name); ?></h3>
                    <p class="text-md-left text-center">
                        <?php echo e($post->intro); ?>

                    </p>
                    <a class="btn btn-pill btn-complementary py-1 small-text"
                       href="<?php echo e(route('blog.article', $post->slug)); ?>">Leer artículo</a>
                </div>
                <div class="images img-dots-pattern col-md-6 col-11 offset-md-0 offset-1 px-0">
                    <img class="img-fluid" src="<?php echo e(asset($post->getFirstMediaUrl('blog-cover'))); ?>" alt="">
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    </section>

    <script src="<?php echo e(asset('lib/swiper/swiper-bundle.min.js')); ?>"></script>
    <script>
        var swiper = new Swiper('.swiper-events', {
            slidesPerView: 3,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\sertei\resources\views/sections/blog.blade.php ENDPATH**/ ?>