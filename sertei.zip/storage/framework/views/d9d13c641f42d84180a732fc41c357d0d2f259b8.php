<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('icon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('icon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('icon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('icon/site.webmanifest')); ?>">
    <link rel="mask-icon" href="<?php echo e(asset('icon/safari-pinned-tab.svg')); ?>" color="#5bbad5">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="theme-color" content="#ffffff">

    <title><?php echo e(config('app.name', 'Site name')); ?></title>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <!-- Fonts -->
    <link href="<?php echo e(asset('fontawesome/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Muli:wght@400;700&display=swap">

    <link href="<?php echo e(asset('dashboard/css/sb-admin-2.css')); ?>" rel="stylesheet">

    <?php echo $__env->yieldContent('styles'); ?>

</head>

<body class="<?php echo $__env->yieldContent('body-class'); ?>" id="page-top">
    <?php echo $__env->yieldContent('body'); ?>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\sertei\resources\views/dashboard/layouts/base.blade.php ENDPATH**/ ?>