<nav class="navbar navbar-light site-nav bg-white navbar-expand-md px-md-4 py-md-0 fixed-top">
    <a class="navbar-brand p-0" href="<?php echo e(route('home')); ?>">
        <img src="<?php echo e(asset('./img/icons/logo.png')); ?>" width="30" height="30" class="d-inline-block align-top" alt="logo sertei">
    </a>
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar-main" aria-controls="navbar-main" aria-expanded="false" aria-label="Toggle navigation">
        <img src="<?php echo e(asset('./img/icons/icon-toggler.png')); ?>" alt="">
    </button>

    <div class="collapse navbar-collapse" id="navbar-main">
        <ul class="navbar-nav d-md-flex ml-auto text-center bg-white">
            <li class="nav-item <?php echo e(request()->is('quienes-somos') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('us')); ?>">Quiénes somos</a>
            </li>

            <li class="nav-item dropdown <?php echo e(request()->is('soluciones*') ? 'active' : ''); ?>">
                <a class="nav-link" href="#" id="navbarDropdownsolutions" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Soluciones
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownsolutions">
                    <a class="dropdown-item dropdown-item-top <?php echo e(request()->is('soluciones/infraestructura') ? 'active' : ''); ?>" href="<?php echo e(route('infrastructure')); ?>">
                        Infraestructura
                    </a>
                    <a class="dropdown-item <?php echo e(request()->is('soluciones/seguridad') ? 'active' : ''); ?>" href="<?php echo e(route('security')); ?>">
                        Seguridad
                    </a>
                </div>
            </li>

            <li class="nav-item <?php echo e(request()->is('servicios') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('services')); ?>">Servicios</a>
            </li>

            <li class="nav-item <?php echo e(request()->is('aliados-estrategicos') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('allies')); ?>">Aliados estratégicos</a>
            </li>

            <li class="nav-item <?php echo e(request()->is('blog*') || request()->is('evento*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('blog')); ?>">Blog</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('soporte') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('support')); ?>">Soporte</a>
            </li>
            <li class="nav-item <?php echo e(request()->is('contacto') ? 'active' : ''); ?>">
                <a class="nav-link last-child" href="<?php echo e(route('contact')); ?>">Contacto</a>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\laravel\sertei\resources\views/layout/_nav.blade.php ENDPATH**/ ?>